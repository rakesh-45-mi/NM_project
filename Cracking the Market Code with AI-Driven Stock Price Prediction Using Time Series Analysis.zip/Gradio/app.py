import gradio as gr
import numpy as np
import pandas as pd
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler

# Load or generate simulated data
np.random.seed(42)
dates = pd.date_range(start="2022-01-01", periods=500, freq='D')
prices = np.cumsum(np.random.randn(500)) + 150
df = pd.DataFrame({'Date': dates, 'Close': prices})

# Preprocessing
scaler = MinMaxScaler()
scaled_data = scaler.fit_transform(df[['Close']])

def create_dataset(data, look_back=60):
    X, y = [], []
    for i in range(look_back, len(data)):
        X.append(data[i-look_back:i, 0])
        y.append(data[i, 0])
    X = np.array(X)
    y = np.array(y)
    X = np.reshape(X, (X.shape[0], X.shape[1], 1))
    return X, y

X, y = create_dataset(scaled_data)

# Train LSTM
model = Sequential()
model.add(LSTM(50, return_sequences=False, input_shape=(X.shape[1], 1)))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mean_squared_error')
model.fit(X, y, epochs=5, batch_size=32, verbose=0)

# Prediction function
def predict_next(prices_input):
    try:
        prices = [float(p.strip()) for p in prices_input.split(",")]
        if len(prices) != 60:
            return "Please provide exactly 60 prices."
        scaled_input = scaler.transform(np.array(prices).reshape(-1, 1))
        X_pred = np.reshape(scaled_input, (1, 60, 1))
        pred_scaled = model.predict(X_pred)[0][0]
        pred = scaler.inverse_transform([[pred_scaled]])[0][0]
        return float(pred)
    except Exception as e:
        return f"Error: {str(e)}"

demo = gr.Interface(
    fn=predict_next,
    inputs=gr.Textbox(label="Enter 60 closing prices (comma-separated)", lines=4),
    outputs="number",
    title="LSTM Stock Price Predictor",
    description="Provide the last 60 stock closing prices to predict the next one"
)

if __name__ == "__main__":
    demo.launch()
