import gradio as gr
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler

# Load trained model (make sure lstm_model.h5 is in the same directory)
model = tf.keras.models.load_model("lstm_model.h5", compile=False)

def predict_next_day(csv_file):
    try:
        df = pd.read_csv(csv_file.name)
        df = df[['Close']]

        # Normalize the data
        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(df.values)

        # Get last 10 days of prices
        if len(scaled_data) < 10:
            return "Need at least 10 data points in the CSV"
        last_seq = scaled_data[-10:].reshape(1, 10, 1)

        # Predict
        pred_scaled = model.predict(last_seq)
        pred = scaler.inverse_transform(pred_scaled)
        return f"Predicted Close Price: {float(pred[0][0]):.2f}"

    except Exception as e:
        return f"Error: {str(e)}"

# Gradio interface
iface = gr.Interface(
    fn=predict_next_day,
    inputs=gr.File(label="Upload CSV file with 'Close' column"),
    outputs="text",
    title="Stock Price Predictor (LSTM)",
    description="Upload a CSV containing recent stock data with a 'Close' column to predict the next closing price."
)

if __name__ == "__main__":
    iface.launch()
